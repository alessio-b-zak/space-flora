BEFORE RUNNING THE WEB STUFF

Use pip to install
 - flask
 - flask-wtf

Then when in space-flora directory, on WINDOWS run
 > set FLASK_APP=h.py

Or on LINUX run
 > export FLASK_APP=h.py


Once this is done, run
 > flask run

Navigate to 127.0.0.1:5000 for the web interface

Follow this dudes blog for great things https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-i-hello-world